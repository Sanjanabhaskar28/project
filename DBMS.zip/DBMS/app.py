from flask import Flask, render_template, request, redirect, url_for
import mysql.connector

app = Flask(__name__)

db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="your_password",  # Replace with your MySQL password
    database="AirTicketBooking"
)
cursor = db.cursor()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/book', methods=['GET', 'POST'])
def book():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        flight_id = request.form['flight_id']
        seat_number = request.form['seat_number']

        cursor.execute("INSERT INTO Bookings (Booking_ID, User_ID, Flight_ID, Booking_Date, Seat_Number, Booking_Status) VALUES (NULL, 1, %s, NOW(), %s, 'Confirmed')", 
                       (flight_id, seat_number))
        db.commit()
        return redirect(url_for('success'))
    return render_template('book.html')

@app.route('/success')
def success():
    return render_template('success.html')

if __name__ == '__main__':
    app.run(debug=True)
